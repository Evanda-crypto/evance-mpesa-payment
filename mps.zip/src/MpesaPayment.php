<?php

namespace EvanceOdhiambo\MpesaPayment;

class MpesaPayment
{
    // Build your next great package.
}
